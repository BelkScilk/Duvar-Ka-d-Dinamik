# Gündüz Gece – Sistem Temalı Duvar Kâğıdı

Bu sürüm saat kullanmaz; Android'in sistem açık/karanlık görünümünü takip eder:

- Sistem açık mod: tamamen beyaz duvar kâğıdı.
- Sistem karanlık mod: tamamen siyah duvar kâğıdı.
- Canlı duvar kâğıdı görünürken sistem temasını yaklaşık 1 saniyede bir kontrol eder ve yalnızca tema değiştiğinde yeniden çizer.

## İlk kurulum
1. APK'yı telefona kur ve uygulamayı aç.
2. **Canlı duvar kâğıdını ayarla** düğmesine bas.
3. Android önizlemesinde **Duvar kâğıdını ayarla** seçeneğini seç.
4. Ana ekran veya ana ekran ve kilit ekranı seçimini yap.
5. Bundan sonra Hızlı Ayarlar'dan sistem karanlık modunu açıp kapattığında duvar kâğıdı da siyah/beyaz değişir.

## GitHub Actions
ZIP içindeki `settings.gradle`, kök `build.gradle` ve `app/` klasörü aynı proje kökünde bulunur. Gradle Wrapper dahil değildir. Workflow Gradle 8.9 kurup `gradle assembleDebug` çalıştırabilir.
