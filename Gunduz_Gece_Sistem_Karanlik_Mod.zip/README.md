# Gündüz Gece – Sistem Temalı Duvar Kâğıdı

Bu sürüm saat 07:00/19:00 zamanlaması kullanmaz. Android'in sistem görünümünü takip eden canlı duvar kâğıdıdır:

- Sistem açık mod: tamamen beyaz
- Sistem karanlık mod: tamamen siyah

## İlk kurulum
1. APK'yı telefona kur ve uygulamayı aç.
2. **Canlı duvar kâğıdını ayarla** düğmesine bas.
3. Android duvar kâğıdı önizlemesinde **Duvar kâğıdını ayarla** seçeneğini seç.
4. Telefonun sunduğu seçime göre ana ekranı veya ana ekran ve kilit ekranını seç.
5. Bundan sonra telefonun Hızlı Ayarlar bölümünden sistem karanlık modunu açıp kapatınca duvar kâğıdı da siyah/beyaz değişir.

Not: Bu bir canlı duvar kâğıdıdır. Otomatik sistem teması takibi için ilk kez Android'in duvar kâğıdı seçicisinden etkinleştirilmesi gerekir.

## GitHub Actions
ZIP içindeki Android projesini kullan. `settings.gradle`, kök `build.gradle` ve `app/` klasörü aynı proje kökünde bulunur. Gradle Wrapper dahil değildir; workflow Gradle 8.9 kurup `gradle assembleDebug` çalıştırabilir.
