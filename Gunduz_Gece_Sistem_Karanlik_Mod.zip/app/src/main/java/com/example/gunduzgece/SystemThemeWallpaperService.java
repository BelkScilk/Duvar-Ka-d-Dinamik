package com.example.gunduzgece;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.content.res.Configuration;

public class SystemThemeWallpaperService extends WallpaperService {
    @Override
    public Engine onCreateEngine() {
        return new ThemeEngine();
    }

    private class ThemeEngine extends Engine {
        private final Paint paint = new Paint();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private boolean visible;
        private final Runnable drawRunnable = this::drawWallpaper;

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) drawWallpaper();
            else handler.removeCallbacks(drawRunnable);
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawWallpaper();
        }

        @Override
        public void onConfigurationChanged(Configuration newConfig) {
            super.onConfigurationChanged(newConfig);
            // Android calls this when the device's UI night mode changes.
            drawWallpaper();
        }

        private void drawWallpaper() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                int nightMode = getResources().getConfiguration().uiMode
                        & Configuration.UI_MODE_NIGHT_MASK;
                paint.setColor(nightMode == Configuration.UI_MODE_NIGHT_YES
                        ? Color.BLACK : Color.WHITE);
                canvas.drawColor(paint.getColor());
            } catch (IllegalArgumentException ignored) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }
        }
    }
}
