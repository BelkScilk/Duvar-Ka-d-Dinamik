package com.example.gunduzgece;

import android.app.WallpaperColors;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.content.res.Configuration;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

/** Live wallpaper that follows Android's system light/dark appearance. */
public class SystemThemeWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new ThemeEngine();
    }

    private class ThemeEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private boolean visible;
        private int lastNightMode = -1;

        private final Runnable themeCheck = new Runnable() {
            @Override
            public void run() {
                if (!visible) return;

                int currentMode = getResources().getConfiguration().uiMode
                        & Configuration.UI_MODE_NIGHT_MASK;

                if (currentMode != lastNightMode) {
                    lastNightMode = currentMode;
                    drawWallpaper();
                    if (android.os.Build.VERSION.SDK_INT >= 27) {
                        notifyColorsChanged();
                    }
                }
                handler.postDelayed(this, 1000);
            }
        };

        @Override
        public WallpaperColors onComputeColors() {
            if (android.os.Build.VERSION.SDK_INT < 27) {
                return super.onComputeColors();
            }
            int nightMode = getResources().getConfiguration().uiMode
                    & Configuration.UI_MODE_NIGHT_MASK;

            if (nightMode == Configuration.UI_MODE_NIGHT_YES) {
                return new WallpaperColors(Color.valueOf(Color.BLACK), null, null, 0);
            }

            // Tell the launcher that black/dark text is suitable on the white wallpaper.
            return new WallpaperColors(
                    Color.valueOf(Color.WHITE), null, null,
                    WallpaperColors.HINT_SUPPORTS_DARK_TEXT
            );
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            handler.removeCallbacks(themeCheck);
            if (visible) {
                lastNightMode = -1;
                themeCheck.run();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawWallpaper();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            handler.removeCallbacks(themeCheck);
        }

        @Override
        public void onDestroy() {
            visible = false;
            handler.removeCallbacks(themeCheck);
            super.onDestroy();
        }

        private void drawWallpaper() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                int nightMode = getResources().getConfiguration().uiMode
                        & Configuration.UI_MODE_NIGHT_MASK;
                canvas.drawColor(nightMode == Configuration.UI_MODE_NIGHT_YES
                        ? Color.BLACK : Color.WHITE);
            } catch (IllegalArgumentException ignored) {
                // Surface may have been destroyed while drawing.
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }
        }
    }
}
