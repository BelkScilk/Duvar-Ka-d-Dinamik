package com.example.gunduzgece;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 40, 32, 40);

        TextView title = new TextView(this);
        title.setText("Gündüz Gece Duvar Kâğıdı");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("\nTelefonun görünümünü takip eder:\n\n☀ Sistem açık moddaysa: BEYAZ\n☾ Sistem karanlık moddaysa: SİYAH\n\nTelefonun Hızlı Ayarlar bölümünden karanlık modu açıp kapattığında duvar kâğıdı da otomatik değişir.\n\nİlk kullanımda aşağıdaki düğmeye basıp canlı duvar kâğıdını bir kez ayarlaman yeterli.");
        info.setTextSize(17);
        info.setGravity(Gravity.CENTER);

        Button setButton = new Button(this);
        setButton.setText("Canlı duvar kâğıdını ayarla");
        setButton.setOnClickListener(v -> openWallpaperPicker());

        layout.addView(title);
        layout.addView(info);
        layout.addView(setButton);
        setContentView(layout);
    }

    private void openWallpaperPicker() {
        Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, SystemThemeWallpaperService.class));
        startActivity(intent);
    }
}
