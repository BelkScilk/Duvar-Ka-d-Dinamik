# Gunduz Gece Duvar Kagidi

- Sistem acik mod: beyaz duvar kagidi; launcher'a koyu yazi ipucu bildirilir.
- Sistem karanlik mod: siyah duvar kagidi.
- Tema degisimi canli duvar kagidi tarafindan izlenir.
- versionCode 2 / versionName 1.1.
- Sabit imza anahtari sonraki derlemelerde ayni imzanin kullanilmasini saglar.

## Imza anahtari
Bu ZIP kisisel kullanim icin sabit imza anahtari icerir. Depo herkese aciksa anahtar da herkese acik olur; guvenlik icin GitHub deposunu private tut.

Onceki APK gecici GitHub debug anahtariyla imzalanmissa bu sabit imzali surume geciste bir defaya mahsus eski uygulamayi kaldirman gerekebilir. Bundan sonraki guncellemelerde ayni imza kullanilir ve normalde uygulamayi kaldirmak gerekmez.
