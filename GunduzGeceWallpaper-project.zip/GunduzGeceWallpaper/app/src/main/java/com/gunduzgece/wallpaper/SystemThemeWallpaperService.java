package com.gunduzgece.wallpaper;

import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.io.IOException;
import java.io.InputStream;

public class SystemThemeWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new ThemeEngine();
    }

    private class ThemeEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private boolean visible = true;
        private Bitmap dayBitmap;
        private Bitmap nightBitmap;
        private Bitmap currentBitmap;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Matrix matrix = new Matrix();
        private int width, height;
        private boolean isNight = false;

        private final Runnable drawRunner = new Runnable() {
            @Override
            public void run() {
                draw();
            }
        };

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            loadBitmaps();
            updateTheme();
        }

        private void loadBitmaps() {
            try {
                // Load from assets
                InputStream dayStream = getAssets().open("wallpapers/day.jpg");
                dayBitmap = BitmapFactory.decodeStream(dayStream);
                dayStream.close();

                InputStream nightStream = getAssets().open("wallpapers/night.jpg");
                nightBitmap = BitmapFactory.decodeStream(nightStream);
                nightStream.close();
            } catch (IOException e) {
                // Fallback solid colors if images missing
                dayBitmap = null;
                nightBitmap = null;
            }
        }

        private void updateTheme() {
            int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            boolean newIsNight = (nightModeFlags == Configuration.UI_MODE_NIGHT_YES);
            
            if (newIsNight != isNight || currentBitmap == null) {
                isNight = newIsNight;
                currentBitmap = isNight ? nightBitmap : dayBitmap;
            }
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (visible) {
                updateTheme();
                draw();
            } else {
                handler.removeCallbacks(drawRunner);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            this.width = width;
            this.height = height;
            draw();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            this.visible = false;
            handler.removeCallbacks(drawRunner);
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            handler.removeCallbacks(drawRunner);
            if (dayBitmap != null && !dayBitmap.isRecycled()) {
                dayBitmap.recycle();
            }
            if (nightBitmap != null && !nightBitmap.isRecycled()) {
                nightBitmap.recycle();
            }
        }

        private void draw() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas != null) {
                    // Always re-check theme in case system changed
                    updateTheme();

                    if (currentBitmap != null && !currentBitmap.isRecycled()) {
                        // Scale bitmap to fill the screen (center-crop style)
                        float scale;
                        float dx = 0, dy = 0;
                        int bw = currentBitmap.getWidth();
                        int bh = currentBitmap.getHeight();

                        if (bw * height > width * bh) {
                            scale = (float) height / (float) bh;
                            dx = (width - bw * scale) * 0.5f;
                        } else {
                            scale = (float) width / (float) bw;
                            dy = (height - bh * scale) * 0.5f;
                        }

                        matrix.reset();
                        matrix.setScale(scale, scale);
                        matrix.postTranslate(dx, dy);

                        canvas.drawColor(Color.BLACK);
                        canvas.drawBitmap(currentBitmap, matrix, paint);
                    } else {
                        // Fallback solid color
                        canvas.drawColor(isNight ? Color.BLACK : Color.WHITE);
                    }
                }
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (Exception ignored) {
                    }
                }
            }

            handler.removeCallbacks(drawRunner);
            if (visible) {
                // Redraw every 2 seconds to catch theme changes quickly
                handler.postDelayed(drawRunner, 2000);
            }
        }
    }
}
