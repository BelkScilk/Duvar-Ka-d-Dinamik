package com.gunduzgece.wallpaper;

import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Simple layout programmatically (no need for XML layout)
        TextView info = new TextView(this);
        info.setText(R.string.info_text);
        info.setPadding(48, 48, 48, 24);
        info.setTextSize(16);

        Button btn = new Button(this);
        btn.setText(R.string.set_wallpaper);
        btn.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(this, SystemThemeWallpaperService.class));
                startActivity(intent);
            } catch (Exception e) {
                // Fallback for some devices
                try {
                    Intent intent = new Intent(Intent.ACTION_SET_WALLPAPER);
                    startActivity(Intent.createChooser(intent, "Duvar Kağıdı Seç"));
                } catch (Exception ex) {
                    Toast.makeText(this, "Duvar kağıdı ayarlanamadı: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);
        layout.addView(info);
        layout.addView(btn);

        setContentView(layout);
        setTitle(R.string.app_name);
    }
}
