# Gündüz Gece Sistem Teması Duvar Kağıdı

Sistem temasına (Açık / Karanlık mod) göre otomatik değişen canlı duvar kağıdı.

- **Açık mod (Light)** → Parlak karlı dağ manzarası
- **Karanlık mod (Dark)** → Koyu gece dağ manzarası

## Özellikler

- Sistem temasını gerçek zamanlı takip eder
- Yüksek kaliteli resimler (assets içinde)
- Basit ve hafif
- Android 7.0+ (API 24)

## Kurulum (Android Studio)

1. Android Studio ile bu projeyi aç
2. SDK kurulu olduğundan emin ol (API 34 önerilir)
3. `local.properties` dosyasına kendi `sdk.dir` yolunu yaz
4. **Build > Make Project** veya **Run**

## GitHub Actions ile APK Alma

Repo'ya pushladıktan sonra Actions sekmesinden APK indirebilirsin (aşağıdaki workflow eklenmiştir).

## Kullanım

1. Uygulamayı aç
2. **"Duvar Kağıdını Ayarla"** butonuna bas
3. Canlı duvar kağıdını seç ve uygula
4. Sistem temasını değiştirerek test et (Ayarlar > Ekran > Karanlık tema)

## Extra Duvar Kağıtları

`app/src/main/assets/wallpapers/` klasöründe ekstra versiyonlar var:
- day_bright.jpg, day_cool.jpg
- night_dark.jpg, night_moon.jpg

Kodda `day.jpg` / `night.jpg` değiştirerek farklı versiyon kullanabilirsin.

## Lisans

Serbest kullanım.
