# Gündüz Gece Duvar Kâğıdı

Android uygulaması: 07:00'de aydınlık, 19:00'da koyu duvar kâğıdını otomatik uygular.

## GitHub'da APK oluşturma
1. Bu ZIP dosyasını aç.
2. GitHub'da yeni bir repository oluştur.
3. ZIP içindeki dosyaları ve `.github` klasörünü repository'nin ana dizinine yükle.
4. **Actions** sekmesine gir.
5. **Android APK Derle** iş akışını açıp çalışmasını bekle.
6. Başarılı olunca çalışmanın altındaki **Artifacts** bölümünden `Gündüz-Gece-Duvar-Kağıdı-APK` dosyasını indir.
7. ZIP'i açıp `app-debug.apk` dosyasını telefona kur.

## Saatler
Başlangıç saatleri 07:00 ve 19:00 olarak ayarlanmıştır. `MainActivity.java` içindeki saatleri değiştirebilirsin.
