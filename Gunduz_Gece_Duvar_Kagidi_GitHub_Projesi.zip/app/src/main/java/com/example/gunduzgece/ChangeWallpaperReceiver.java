package com.example.gunduzgece;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class ChangeWallpaperReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        boolean night=intent.getBooleanExtra("night", false);
        MainActivity.apply(context,night);
    }
}
