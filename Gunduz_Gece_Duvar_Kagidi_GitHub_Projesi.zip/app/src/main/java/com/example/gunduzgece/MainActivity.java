package com.example.gunduzgece;

import android.app.Activity;
import android.os.Bundle;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Calendar;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        schedule(this);
        applyCurrent(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(36,48,36,48);
        layout.setBackgroundColor(0xFFF4F7FA);
        TextView title = new TextView(this);
        title.setText("Gündüz Gece Duvar Kâğıdı");
        title.setTextSize(25); title.setTextColor(0xFF182536); title.setGravity(Gravity.CENTER);
        TextView info = new TextView(this);
        info.setText("\nHer gün otomatik değişir.\n\n☀ 07:00 — Aydınlık gündüz\n☾ 19:00 — Koyu gece\n\nUygulama açıldığında mevcut saate uygun duvar kâğıdı uygulanır. Telefon yeniden başlatıldığında zamanlama tekrar kurulur.");
        info.setTextSize(17); info.setTextColor(0xFF34465A); info.setGravity(Gravity.CENTER);
        Button now = new Button(this);
        now.setText("Şimdi saate uygun duvar kâğıdını uygula");
        now.setOnClickListener(v -> applyCurrent(this));
        layout.addView(title); layout.addView(info);
        layout.addView(now);
        setContentView(layout);
    }
    static void schedule(Context c) {
        AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE);
        setAlarm(c, am, 7, 0);
        setAlarm(c, am, 19, 1);
    }
    static void setAlarm(Context c, AlarmManager am, int hour, int id) {
        Intent i=new Intent(c, ChangeWallpaperReceiver.class);
        i.putExtra("night", id==1);
        PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Calendar cal=Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY,hour); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0);
        if(cal.getTimeInMillis()<=System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR,1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
    }
    static void applyCurrent(Context c) {
        Calendar cal=Calendar.getInstance();
        boolean night=cal.get(Calendar.HOUR_OF_DAY)>=19 || cal.get(Calendar.HOUR_OF_DAY)<7;
        apply(c,night);
    }
    static void apply(Context c, boolean night) {
        try {
            int id=night?R.drawable.night:R.drawable.day;
            Bitmap bitmap=BitmapFactory.decodeResource(c.getResources(),id);
            WallpaperManager wm=WallpaperManager.getInstance(c);
            if(Build.VERSION.SDK_INT>=24) wm.setBitmap(bitmap,null,true,WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
            else wm.setBitmap(bitmap);
            bitmap.recycle();
        } catch(Exception e) { e.printStackTrace(); }
    }
}
