# Gündüz Gece Duvar Kâğıdı

Android uygulaması, telefonun yerel saatine göre duvar kâğıdını otomatik değiştirir:

- 07:00 — tamamen beyaz duvar kâğıdı
- 19:00 — tamamen siyah duvar kâğıdı

Uygulama açıldığında mevcut saate uygun duvar kâğıdını uygular. Telefon yeniden başlatıldığında zamanlamayı tekrar kurar. Ana ekran ve kilit ekranına uygular.

## Proje yapısı

Bu ZIP'in içeriğini GitHub Actions iş akışınızın açtığı ZIP dosyası olarak kullanın. ZIP'in kökünde `settings.gradle`, `build.gradle` ve `app/` klasörü bulunur.

## Saatleri değiştirme

`app/src/main/java/com/example/gunduzgece/MainActivity.java` dosyasında `7` gündüz, `19` gece başlangıç saatidir.
