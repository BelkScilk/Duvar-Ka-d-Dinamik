package com.example.gunduzgece;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Catalogue of the wallpapers available for the light (day) and the dark (night) system
 * appearance, plus the user's choice for each of the two.
 *
 * Images live in assets/wallpapers/light and assets/wallpapers/dark. Any .jpg, .jpeg, .png
 * or .webp file dropped into those folders is picked up automatically (sorted by file name).
 */
final class WallpaperStore {

    static final String PREFS_NAME = "gunduz_gece";

    /** Selection value meaning "move on to the next wallpaper whenever the system mode switches". */
    static final String SHUFFLE = "shuffle";

    static final String SOLID_BLACK = "solid:black";
    static final String SOLID_WHITE = "solid:white";

    /** Out of the box: the snowy valley photo by day, plain black by night. */
    private static final String DEFAULT_LIGHT = "light/01-karli-daglar.jpg";

    private static final String KEY_CHOICE_LIGHT = "choice_light";
    private static final String KEY_CHOICE_DARK = "choice_dark";
    private static final String KEY_SHUFFLE_LIGHT = "shuffle_light";
    private static final String KEY_SHUFFLE_DARK = "shuffle_dark";
    private static final String KEY_LAST_MODE = "last_mode";

    private static final int MODE_DAY = 1;
    private static final int MODE_NIGHT = 2;

    private static final Locale TR = new Locale("tr", "TR");

    /** Display names of the bundled wallpapers. Other files get a name made from the file name. */
    private static final String[][] LABELS = {
            {"light/01-karli-daglar.jpg", "Karlı Dağlar"},
            {"light/02-sisli-daglar.jpg", "Sisli Dağlar"},
            {"light/03-pastel-safak.jpg", "Pastel Şafak"},
            {"light/04-beyaz-dalgalar.jpg", "Beyaz Dalgalar"},
            {"light/05-beyaz-ipek.jpg", "Beyaz İpek"},
            {"dark/01-yildizli-gece.jpg", "Yıldızlı Gece"},
            {"dark/02-kuzey-isiklari.jpg", "Kuzey Işıkları"},
            {"dark/03-gece-sisi.jpg", "Gece Sisi"},
            {"dark/04-koyu-ipek.jpg", "Koyu İpek"},
    };

    /** Lists the files of an assets folder (backed by AssetManager.list in the app). */
    interface AssetLister {
        String[] list(String dir);
    }

    /** One selectable wallpaper: an image from assets, or a plain colour. */
    static final class Item {
        final String id;
        final String label;
        final boolean dark;
        /** Path inside assets/, or null for a plain colour. */
        final String assetPath;
        final int solidColor;

        Item(String id, String label, boolean dark, String assetPath, int solidColor) {
            this.id = id;
            this.label = label;
            this.dark = dark;
            this.assetPath = assetPath;
            this.solidColor = solidColor;
        }

        boolean isSolid() {
            return assetPath == null;
        }
    }

    private final SharedPreferences prefs;
    private final List<Item> lightItems;
    private final List<Item> darkItems;

    WallpaperStore(SharedPreferences prefs, AssetLister lister) {
        this.prefs = prefs;
        this.lightItems = Collections.unmodifiableList(build(lister, false));
        this.darkItems = Collections.unmodifiableList(build(lister, true));
    }

    static WallpaperStore create(Context context) {
        final AssetManager assets = context.getAssets();
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return new WallpaperStore(prefs, new AssetLister() {
            @Override
            public String[] list(String dir) {
                try {
                    String[] names = assets.list(dir);
                    return names != null ? names : new String[0];
                } catch (IOException e) {
                    return new String[0];
                }
            }
        });
    }

    // ------------------------------------------------------------------ catalogue

    private static List<Item> build(AssetLister lister, boolean dark) {
        String folder = dark ? "dark" : "light";
        ArrayList<Item> out = new ArrayList<>();
        String[] names = lister.list("wallpapers/" + folder);
        if (names != null) {
            String[] sorted = names.clone();
            Arrays.sort(sorted);
            for (String name : sorted) {
                if (!isImageName(name)) continue;
                String id = folder + "/" + name;
                out.add(new Item(id, labelFor(id, name), dark, "wallpapers/" + id, 0));
            }
        }
        if (dark) {
            out.add(0, new Item(SOLID_BLACK, "Saf Siyah", true, null, 0xFF000000));
        } else {
            out.add(new Item(SOLID_WHITE, "Düz Beyaz", false, null, 0xFFFFFFFF));
        }
        return out;
    }

    private static boolean isImageName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".webp");
    }

    static String labelFor(String id, String fileName) {
        for (String[] pair : LABELS) {
            if (pair[0].equals(id)) return pair[1];
        }
        String s = fileName;
        int dot = s.lastIndexOf('.');
        if (dot > 0) s = s.substring(0, dot);
        int i = 0;
        while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
        while (i < s.length() && (s.charAt(i) == '-' || s.charAt(i) == '_' || s.charAt(i) == ' ')) i++;
        s = s.substring(i).replace('-', ' ').replace('_', ' ').trim();
        if (s.isEmpty()) return fileName;
        return s.substring(0, 1).toUpperCase(TR) + s.substring(1);
    }

    /** All wallpapers of the dark (true) or the light (false) set, in display order. */
    List<Item> items(boolean dark) {
        return dark ? darkItems : lightItems;
    }

    // ------------------------------------------------------------------ selection

    /** The wallpaper to show right now for the given system mode. */
    Item resolve(boolean dark) {
        List<Item> list = items(dark);
        String choice = prefs.getString(choiceKey(dark), null);
        Item found;
        if (SHUFFLE.equals(choice)) {
            found = find(list, prefs.getString(shuffleKey(dark), null));
        } else {
            found = find(list, choice);
        }
        return found != null ? found : fallback(dark);
    }

    /** What the picker should highlight: an item id, or SHUFFLE. */
    String selectedId(boolean dark) {
        if (SHUFFLE.equals(prefs.getString(choiceKey(dark), null))) return SHUFFLE;
        return resolve(dark).id;
    }

    /** Stores the user's pick for one mode. {@code id} is an item id or SHUFFLE. */
    void select(boolean dark, String id) {
        SharedPreferences.Editor editor = prefs.edit();
        if (SHUFFLE.equals(id)) {
            // Keep what is on screen now; the next switch of the system mode moves on.
            editor.putString(shuffleKey(dark), resolve(dark).id);
            editor.putString(choiceKey(dark), SHUFFLE);
        } else if (find(items(dark), id) != null) {
            editor.putString(choiceKey(dark), id);
        } else {
            return;
        }
        editor.apply();
    }

    /**
     * Called by the live wallpaper whenever it looks at the system mode. When the mode has
     * changed since the last look, the set that is now active moves on if it is in SHUFFLE mode.
     */
    void onModeObserved(boolean dark) {
        int mode = dark ? MODE_NIGHT : MODE_DAY;
        int last = prefs.getInt(KEY_LAST_MODE, 0);
        if (last == mode) return;
        if (last != 0) advanceShuffle(dark);
        prefs.edit().putInt(KEY_LAST_MODE, mode).apply();
    }

    private void advanceShuffle(boolean dark) {
        if (!SHUFFLE.equals(prefs.getString(choiceKey(dark), null))) return;
        List<Item> pool = pool(dark);
        if (pool.isEmpty()) return;
        String current = prefs.getString(shuffleKey(dark), null);
        int index = -1;
        for (int i = 0; i < pool.size(); i++) {
            if (pool.get(i).id.equals(current)) {
                index = i;
                break;
            }
        }
        Item next = pool.get((index + 1) % pool.size());
        prefs.edit().putString(shuffleKey(dark), next.id).apply();
    }

    /** Wallpapers that take part in SHUFFLE: the images, or everything if there are no images. */
    private List<Item> pool(boolean dark) {
        List<Item> all = items(dark);
        ArrayList<Item> images = new ArrayList<>();
        for (Item item : all) {
            if (!item.isSolid()) images.add(item);
        }
        return images.isEmpty() ? all : images;
    }

    private Item fallback(boolean dark) {
        List<Item> list = items(dark);
        Item preferred = find(list, dark ? SOLID_BLACK : DEFAULT_LIGHT);
        return preferred != null ? preferred : list.get(0);
    }

    private static Item find(List<Item> list, String id) {
        if (id == null) return null;
        for (Item item : list) {
            if (item.id.equals(id)) return item;
        }
        return null;
    }

    private static String choiceKey(boolean dark) {
        return dark ? KEY_CHOICE_DARK : KEY_CHOICE_LIGHT;
    }

    private static String shuffleKey(boolean dark) {
        return dark ? KEY_SHUFFLE_DARK : KEY_SHUFFLE_LIGHT;
    }
}
