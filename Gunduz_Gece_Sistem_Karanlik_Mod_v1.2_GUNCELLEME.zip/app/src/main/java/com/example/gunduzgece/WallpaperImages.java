package com.example.gunduzgece;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.IOException;
import java.io.InputStream;

/** Loads wallpaper images from assets without decoding more pixels than needed. */
final class WallpaperImages {

    private WallpaperImages() {
    }

    /**
     * Decodes an image so that it still covers reqWidth x reqHeight (scale-to-cover), using the
     * largest power-of-two down-sampling that keeps it that large. Returns null for plain
     * colours, unreadable files or when memory runs out.
     */
    static Bitmap decodeCover(AssetManager assets, WallpaperStore.Item item, int reqWidth, int reqHeight) {
        if (item.assetPath == null || reqWidth <= 0 || reqHeight <= 0) return null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = assets.open(item.assetPath)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

            float cover = Math.max((float) reqWidth / bounds.outWidth,
                    (float) reqHeight / bounds.outHeight);
            int sample = 1;
            while (cover * sample * 2f <= 1f) sample *= 2;

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            try (InputStream in = assets.open(item.assetPath)) {
                return BitmapFactory.decodeStream(in, null, options);
            }
        } catch (IOException | OutOfMemoryError e) {
            return null;
        }
    }
}
