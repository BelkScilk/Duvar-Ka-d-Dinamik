package com.example.gunduzgece;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

public class MainActivity extends Activity {

    private static final int TILE_WIDTH_DP = 92;
    private static final int TILE_HEIGHT_DP = 164;

    /** One tappable wallpaper preview in a row. */
    private static final class Tile {
        final String id;
        final View cell;
        final FrameLayout frame;
        final TextView name;
        final TextView check;
        final int nameColor;

        Tile(String id, View cell, FrameLayout frame, TextView name, TextView check) {
            this.id = id;
            this.cell = cell;
            this.frame = frame;
            this.name = name;
            this.check = check;
            this.nameColor = name.getCurrentTextColor();
        }
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Tile> lightTiles = new ArrayList<>();
    private final List<Tile> darkTiles = new ArrayList<>();

    private WallpaperStore store;
    private ExecutorService loader;
    private TextView statusView;
    private boolean destroyed;
    private float density;
    private int accent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = getResources().getDisplayMetrics().density;
        accent = resolveAccent();
        store = WallpaperStore.create(this);
        loader = Executors.newSingleThreadExecutor();
        setContentView(buildContent());
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        loader.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ layout

    private View buildContent() {
        final int pad = dp(20);

        final LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(pad, pad, pad, pad);

        TextView title = label("Gündüz Gece Duvar Kâğıdı", 26, true);
        title.setGravity(Gravity.CENTER);
        column.addView(title, fullWidth(0, dp(8)));

        statusView = label("", 15, true);
        statusView.setGravity(Gravity.CENTER);
        statusView.setTextColor(accent);
        column.addView(statusView, fullWidth(0, dp(12)));

        TextView info = label("Telefonun görünümünü takip eder: açık modda gündüz, karanlık modda "
                + "gece duvar kâğıdın görünür. Her mod için aşağıdan istediğin duvar kâğıdını seç; "
                + "seçimin hemen kaydedilir.", 16, false);
        info.setGravity(Gravity.CENTER);
        column.addView(info, fullWidth(0, dp(16)));

        Button setButton = new Button(this);
        setButton.setText("Canlı duvar kâğıdını ayarla");
        setButton.setOnClickListener(v -> openWallpaperPicker());
        column.addView(setButton, fullWidth(0, dp(8)));

        addSection(column, false, "☀ Gündüz (açık mod)", "Telefon açık moddayken görünür.");
        addSection(column, true, "☾ Gece (karanlık mod)", "Telefon karanlık moddayken görünür.");

        TextView tip = label("Sırayla: sistem modu her değiştiğinde o moddaki bir sonraki "
                + "duvar kâğıdına geçer.", 13, false);
        tip.setAlpha(0.7f);
        column.addView(tip, fullWidth(dp(20), 0));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(column, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // Android 15 draws apps edge to edge: keep the content clear of the system bars.
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            column.setPadding(pad + insets.getSystemWindowInsetLeft(),
                    pad + insets.getSystemWindowInsetTop(),
                    pad + insets.getSystemWindowInsetRight(),
                    pad + insets.getSystemWindowInsetBottom());
            return insets;
        });
        return scroll;
    }

    private void addSection(LinearLayout parent, boolean dark, String title, String hint) {
        TextView header = label(title, 19, true);
        parent.addView(header, fullWidth(dp(24), 0));

        TextView sub = label(hint, 13, false);
        sub.setAlpha(0.7f);
        parent.addView(sub, fullWidth(0, 0));

        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(10), 0, dp(4));
        scroller.addView(row);
        parent.addView(scroller, fullWidth(0, 0));

        List<Tile> tiles = dark ? darkTiles : lightTiles;
        for (WallpaperStore.Item item : store.items(dark)) {
            Tile tile = buildTile(dark, item.id, item.label, item);
            tiles.add(tile);
            row.addView(tile.cell);
        }
        Tile shuffle = buildTile(dark, WallpaperStore.SHUFFLE, "Sırayla", null);
        tiles.add(shuffle);
        row.addView(shuffle.cell);

        refreshSelection(dark);
    }

    private Tile buildTile(final boolean dark, final String id, final String labelText,
                           final WallpaperStore.Item item) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setClickable(true);
        cell.setFocusable(true);
        cell.setContentDescription(labelText);
        LinearLayout.LayoutParams cellParams = new LinearLayout.LayoutParams(
                dp(TILE_WIDTH_DP + 6), ViewGroup.LayoutParams.WRAP_CONTENT);
        cellParams.rightMargin = dp(10);
        cell.setLayoutParams(cellParams);

        FrameLayout frame = new FrameLayout(this);
        frame.setPadding(dp(3), dp(3), dp(3), dp(3));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        roundCorners(image, dp(13));
        frame.addView(image, new FrameLayout.LayoutParams(dp(TILE_WIDTH_DP), dp(TILE_HEIGHT_DP)));

        if (item == null) {
            // The "Sırayla" tile has no picture of its own.
            int top = dark ? 0xFF1B2A4A : 0xFFD6E6F7;
            int bottom = dark ? 0xFF000000 : 0xFFFBEBDD;
            image.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{top, bottom}));
            TextView glyph = label("↻", 40, true);
            glyph.setGravity(Gravity.CENTER);
            glyph.setTextColor(dark ? Color.WHITE : 0xFF2B3A55);
            frame.addView(glyph,
                    new FrameLayout.LayoutParams(dp(TILE_WIDTH_DP), dp(TILE_HEIGHT_DP)));
        } else if (item.isSolid()) {
            image.setBackgroundColor(item.solidColor);
        } else {
            loadThumbnail(item, image);
        }

        TextView check = label("✓", 14, true);
        check.setGravity(Gravity.CENTER);
        check.setTextColor(Color.WHITE);
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(accent);
        check.setBackground(dot);
        FrameLayout.LayoutParams checkParams =
                new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP | Gravity.END);
        checkParams.setMargins(0, dp(9), dp(9), 0);
        frame.addView(check, checkParams);

        TextView name = label(labelText, 12, false);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);

        cell.addView(frame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.addView(name, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        cell.setOnClickListener(v -> onTileClicked(dark, id, labelText));

        return new Tile(id, cell, frame, name, check);
    }

    // ------------------------------------------------------------------ behaviour

    private void onTileClicked(boolean dark, String id, String labelText) {
        store.select(dark, id);
        refreshSelection(dark);
        Toast.makeText(this, (dark ? "Gece: " : "Gündüz: ") + labelText, Toast.LENGTH_SHORT).show();
    }

    private void refreshSelection(boolean dark) {
        String selected = store.selectedId(dark);
        for (Tile tile : dark ? darkTiles : lightTiles) {
            boolean on = tile.id.equals(selected);
            GradientDrawable border = new GradientDrawable();
            border.setCornerRadius(dp(16));
            border.setStroke(dp(on ? 3 : 1), on ? accent : 0x40808080);
            tile.frame.setBackground(border);
            tile.check.setVisibility(on ? View.VISIBLE : View.GONE);
            tile.name.setTypeface(Typeface.DEFAULT, on ? Typeface.BOLD : Typeface.NORMAL);
            tile.name.setTextColor(on ? accent : tile.nameColor);
        }
    }

    private void updateStatus() {
        boolean night = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        statusView.setText(night ? "Şu an telefon: ☾ karanlık modda" : "Şu an telefon: ☀ açık modda");
    }

    private void loadThumbnail(final WallpaperStore.Item item, final ImageView target) {
        final int width = dp(TILE_WIDTH_DP);
        final int height = dp(TILE_HEIGHT_DP);
        try {
            loader.execute(() -> {
                final Bitmap bitmap = WallpaperImages.decodeCover(getAssets(), item, width, height);
                if (bitmap == null) return;
                ui.post(() -> {
                    if (destroyed) {
                        bitmap.recycle();
                    } else {
                        target.setImageBitmap(bitmap);
                    }
                });
            });
        } catch (RejectedExecutionException ignored) {
            // Activity is closing.
        }
    }

    private void openWallpaperPicker() {
        Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, SystemThemeWallpaperService.class));
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (ActivityNotFoundException ignored) {
                Toast.makeText(this, "Bu telefonda canlı duvar kâğıdı seçici bulunamadı.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private TextView label(String text, float sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private LinearLayout.LayoutParams fullWidth(int topMargin, int bottomMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = topMargin;
        params.bottomMargin = bottomMargin;
        return params;
    }

    private static void roundCorners(View view, final int radiusPx) {
        view.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx);
            }
        });
        view.setClipToOutline(true);
    }

    private int resolveAccent() {
        TypedValue value = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.colorAccent, value, true)) {
            return value.data;
        }
        return 0xFF3D7BFF;
    }

    private int dp(int value) {
        return Math.round(value * density);
    }
}
