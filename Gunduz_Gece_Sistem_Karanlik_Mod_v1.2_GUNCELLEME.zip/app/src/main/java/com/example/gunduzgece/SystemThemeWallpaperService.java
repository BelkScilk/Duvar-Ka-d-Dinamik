package com.example.gunduzgece;

import android.app.WallpaperColors;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

/**
 * Live wallpaper that follows Android's system light/dark appearance.
 * Light mode shows the wallpaper picked for the day, dark mode the one picked for the night.
 */
public class SystemThemeWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new ThemeEngine();
    }

    private class ThemeEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final WallpaperStore store = WallpaperStore.create(SystemThemeWallpaperService.this);
        private final Matrix matrix = new Matrix();
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

        private boolean visible;
        private int lastNightMode = -1;
        private String lastItemId;

        // Decoded image of the wallpaper on screen (kept so redraws are cheap).
        private Bitmap bitmap;
        private String bitmapId;
        private int bitmapWidth;
        private int bitmapHeight;

        private final Runnable themeCheck = new Runnable() {
            @Override
            public void run() {
                if (!visible) return;

                int currentMode = getResources().getConfiguration().uiMode
                        & Configuration.UI_MODE_NIGHT_MASK;
                boolean night = currentMode == Configuration.UI_MODE_NIGHT_YES;

                // Moves a "Sırayla" (shuffle) set on when the system mode has just switched.
                store.onModeObserved(night);
                WallpaperStore.Item item = store.resolve(night);

                // Redraw when the system mode changed or the user picked another wallpaper.
                if (currentMode != lastNightMode || !item.id.equals(lastItemId)) {
                    lastNightMode = currentMode;
                    lastItemId = item.id;
                    drawWallpaper();
                    if (Build.VERSION.SDK_INT >= 27) {
                        notifyColorsChanged();
                    }
                }
                handler.postDelayed(this, 1000);
            }
        };

        @Override
        public WallpaperColors onComputeColors() {
            if (Build.VERSION.SDK_INT < 27) {
                return super.onComputeColors();
            }
            return colorsFor(store.resolve(isNight()));
        }

        @Override
        public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            handler.removeCallbacks(themeCheck);
            if (visible) {
                lastNightMode = -1;
                themeCheck.run();
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawWallpaper();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            handler.removeCallbacks(themeCheck);
            releaseBitmap();
        }

        @Override
        public void onDestroy() {
            visible = false;
            handler.removeCallbacks(themeCheck);
            releaseBitmap();
            super.onDestroy();
        }

        private boolean isNight() {
            return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                    == Configuration.UI_MODE_NIGHT_YES;
        }

        private void drawWallpaper() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                paintItem(canvas, store.resolve(isNight()));
            } catch (IllegalArgumentException | IllegalStateException ignored) {
                // Surface may have been destroyed while drawing.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (IllegalArgumentException | IllegalStateException ignored) {
                        // Surface went away; nothing left to post.
                    }
                }
            }
        }

        /** Fills the canvas with a plain colour or the chosen image, scaled to cover and centred. */
        private void paintItem(Canvas canvas, WallpaperStore.Item item) {
            int width = canvas.getWidth();
            int height = canvas.getHeight();
            if (item.isSolid()) {
                canvas.drawColor(item.solidColor);
                return;
            }
            // Plain backdrop first: it is what stays visible if the image cannot be loaded.
            canvas.drawColor(item.dark ? Color.BLACK : Color.WHITE);
            Bitmap image = bitmapFor(item, width, height);
            if (image == null) return;

            float scale = Math.max((float) width / image.getWidth(),
                    (float) height / image.getHeight());
            float dx = (width - image.getWidth() * scale) / 2f;
            float dy = (height - image.getHeight() * scale) / 2f;
            matrix.setScale(scale, scale);
            matrix.postTranslate(dx, dy);
            canvas.drawBitmap(image, matrix, paint);
        }

        private Bitmap bitmapFor(WallpaperStore.Item item, int width, int height) {
            if (bitmap != null && item.id.equals(bitmapId)
                    && width == bitmapWidth && height == bitmapHeight) {
                return bitmap;
            }
            releaseBitmap();
            Bitmap decoded = WallpaperImages.decodeCover(getAssets(), item, width, height);
            if (decoded != null) {
                bitmap = decoded;
                bitmapId = item.id;
                bitmapWidth = width;
                bitmapHeight = height;
            }
            return decoded;
        }

        private void releaseBitmap() {
            if (bitmap != null) {
                bitmap.recycle();
                bitmap = null;
            }
            bitmapId = null;
        }

        /**
         * Colours reported to the launcher / system: they tint the system accent and decide whether
         * clock and icons use dark text. Light wallpapers allow dark text, dark ones do not.
         */
        private WallpaperColors colorsFor(WallpaperStore.Item item) {
            boolean darkText = !item.dark;
            if (item.isSolid()) {
                return solidColors(item.solidColor, darkText);
            }
            Bitmap small = WallpaperImages.decodeCover(getAssets(), item, 128, 128);
            if (small == null) {
                return solidColors(item.dark ? Color.BLACK : Color.WHITE, darkText);
            }
            try {
                WallpaperColors fromImage = WallpaperColors.fromBitmap(small);
                if (Build.VERSION.SDK_INT >= 31) {
                    return new WallpaperColors(
                            fromImage.getPrimaryColor(),
                            fromImage.getSecondaryColor(),
                            fromImage.getTertiaryColor(),
                            darkText ? WallpaperColors.HINT_SUPPORTS_DARK_TEXT : 0);
                }
                return fromImage;
            } catch (RuntimeException e) {
                return solidColors(item.dark ? Color.BLACK : Color.WHITE, darkText);
            } finally {
                small.recycle();
            }
        }

        private WallpaperColors solidColors(int color, boolean darkText) {
            if (Build.VERSION.SDK_INT >= 31) {
                return new WallpaperColors(Color.valueOf(color), null, null,
                        darkText ? WallpaperColors.HINT_SUPPORTS_DARK_TEXT : 0);
            }
            // Older systems cannot be given hints directly; let them measure a 1x1 bitmap.
            Bitmap pixel = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            try {
                pixel.eraseColor(color);
                return WallpaperColors.fromBitmap(pixel);
            } finally {
                pixel.recycle();
            }
        }
    }
}
