# Gunduz Gece Duvar Kagidi

Canli duvar kagidi: telefonun sistem gorunumunu (acik / karanlik mod) takip eder.

- Sistem acik mod: GUNDUZ duvar kagidi (varsayilan: Karli Daglar fotografi). Launcher'a koyu yazi ipucu bildirilir.
- Sistem karanlik mod: GECE duvar kagidi (varsayilan: saf siyah).
- Mod degisince duvar kagidi otomatik degisir; hicbir seyi elle degistirmen gerekmez.
- Uygulamayi acinca her mod icin duvar kagidi secebilirsin. "Sirayla" secenegi, sistem modu her
  degistiginde o moddaki siradaki duvar kagidina gecer.
- versionCode 3 / versionName 1.2.
- Sabit imza anahtari sonraki derlemelerde ayni imzanin kullanilmasini saglar.

## Duvar kagitlari
Dosyalar `app/src/main/assets/wallpapers/` altinda:

- `light/` : acik tonlu (gunduz) duvar kagitlari
  - Karli Daglar (senin fotografin, varsayilan), Sisli Daglar, Pastel Safak, Beyaz Dalgalar, Beyaz Ipek, Duz Beyaz
- `dark/`  : koyu (gece) duvar kagitlari
  - Saf Siyah (varsayilan), Yildizli Gece, Kuzey Isiklari, Gece Sisi, Koyu Ipek

Karli Daglar disindaki gorseller bu proje icin ozel uretilmistir; telif sorunu yoktur.

Buraya `.jpg`, `.png` veya `.webp` dosyasi koymak yeterli; kod degistirmeden listede gorunur.
Dosya adlarinin basina `01-`, `02-` gibi rakam koyarak siralamayi belirleyebilirsin.
Onerilen boyut: 1440x3120 (dikey). Gorsel ekrana "kapla ve ortala" seklinde oturur; onemli kisimlari
ortada tut. Listedeki "Duz Beyaz" ve "Saf Siyah" secenekleri kodla gelir, dosya gerektirmez.

Gunduz varsayilani `WallpaperStore.java` icindeki `DEFAULT_LIGHT` degeridir. Gorsellere ekrandaki
Turkce adlari vermek istersen ayni dosyadaki `LABELS` listesine ekle; eklemezsen ad dosya adindan uretilir.

## Imza anahtari
Bu ZIP kisisel kullanim icin sabit imza anahtari icerir. Depo herkese aciksa anahtar da herkese acik olur; guvenlik icin GitHub deposunu private tut.

Onceki APK gecici GitHub debug anahtariyla imzalanmissa bu sabit imzali surume geciste bir defaya mahsus eski uygulamayi kaldirman gerekebilir. Bundan sonraki guncellemelerde ayni imza kullanilir ve normalde uygulamayi kaldirmak gerekmez.
