# Gündüz / Gece Sistem Teması Duvar Kağıdı Paketi

Bu paket, sistem temasına (Açık / Karanlık mod) göre otomatik değişen duvar kağıtları için hazırlanmıştır.

## İçerik

### day/ klasörü (Açık / Gündüz modu için)
- 01_snowy_mountains_day.jpg → Senin seçtiğin orijinal karlı dağ manzarası
- 02_snowy_mountains_bright.jpg → Biraz daha parlak versiyon
- 03_snowy_mountains_cool.jpg → Daha serin tonlu versiyon

### night/ klasörü (Karanlık / Gece modu için)
- 01_snowy_mountains_night.jpg → Karanlık mavi tonlu gece versiyonu
- 02_snowy_mountains_dark.jpg → Çok koyu, desature edilmiş versiyon
- 03_snowy_mountains_moonlight.jpg → Ay ışığı hissi veren versiyon

### gunduz-gece.apk
Orijinal canlı duvar kağıdı uygulaması (şu an solid renk: gündüz beyaz, gece siyah çiziyor). 
Sistem temasına göre otomatik değişiyor.

## Nasıl Kullanılır?

### Yöntem 1: Otomatik Sistem Teması (Önerilen)
1. Aşağıdaki uygulamalardan birini kullan:
   - **Wallpaper Engine** veya **Muzei** (plugin ile)
   - **Tasker** + AutoWallpaper
   - **MacroDroid**
   - **Day & Night Wallpaper** tarzı uygulamalar
   - Veya **KWGT / KLWP** ile sistem teması dinleyerek

2. day/ klasöründeki resimleri "Light / Day" olarak, night/ klasöründekileri "Dark / Night" olarak ayarla.

### Yöntem 2: Manuel
- Sistem açık moddayken day/ içinden birini ayarla
- Sistem karanlık moda geçince night/ içinden birini ayarla

### Yöntem 3: APK'yı Geliştirme
APK şu an sadece solid renk kullanıyor. Resimli hale getirmek için kaynak kodda Bitmap yükleme eklenmesi gerekir.
GitHub'a yükleyip istersen geliştirilebilir.

## Not
Resimler 1024x1654 çözünürlüğünde (portre). İstersen kendi telefonuna göre yeniden boyutlandırabilirsin.

Hazırlayan: Grok (xAI)
